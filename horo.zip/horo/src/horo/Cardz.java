/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package horo;


import java.text.SimpleDateFormat;
import java.util.Random;
import java.util.Date;


class Time{
    
 public static int Dateday; //encap

 public static void Predict(){
      Date current = new Date(); //สร้างobj 
     SimpleDateFormat Aday = new SimpleDateFormat("u");
     Dateday = Integer.parseInt(Aday.format(current));   
      
  
     if(Dateday == 1){
         mon day = new mon();
         day.setVisible(true);    
     }
      if(Dateday == 2){
         Tues day = new Tues();
         day.setVisible(true);    
     }
      if(Dateday == 3){
         Wed day = new Wed();
         day.setVisible(true);    
     }
      if(Dateday == 4){
         thurs day = new thurs();
         day.setVisible(true);    
     }
      if(Dateday == 5){
         fri day = new fri();
         day.setVisible(true);    
     }
      if(Dateday == 6){
         Sat day = new Sat();
         day.setVisible(true);    
     }
      if(Dateday == 7){
         Sun day = new Sun();
         day.setVisible(true);    
     }
      
 }
  }

class Cardz{
    int X,Y;
    int Number;
    public static int amount=0; //จำนวนobj
    public static int[][] Locate = new int[6][2]; //Array ของตำแหน่ง ไพ่ 6 ใบ //2คือ x,y
    public Cardz(int n,int x, int y){ //constructor
        X = x;
        Y = y;
        Number = n;
        
    }
    
    public static int[] Random(int n){
        Random rand = new Random(); //สร้าง obj random
        
        boolean same;
        int[] random = new int[n]; 
        
        random[0] = rand.nextInt(n); //randomตัวเลข 4    4 2 3 5
        for(int i=1; i< random.length;i++){ // i =  // 0 1 2 3 4 
            same=true;    //จะเข้าloop while
            while(same){
                random[i] = rand.nextInt(n);             
                same = false;
                for(int j=i; j>=0; j--){  // j = 0
                    if(i != j){ //ไม่เช็คตำแหน่งตัวเอง 
                        if(random[i] == random[j]) //ตำแหน่ง i เทียบ j
                            same = true;
                    }
                }
            }
        }
        return random;
    }

    public void SetPoint(int Random){ //เปลี่ยนค่าxy จาก random
        for(int i=0;i<Locate.length;i++)          
        System.out.print(i+"= "+Locate[i][0]+" "+Locate[i][1]+" / ");
        X=Locate[Random][0]; 
        Y=Locate[Random][1]; 
        System.out.println();
        System.out.println(Random+"= "+X+" "+Y);
                
        
        
    }
    
   
}
class DayCard extends Cardz{ //inheri
    public DayCard(int n, int x, int y) {
        super(n, x, y); //Polymorphism
        Locate[amount][0]=x; //Abstraction
        Locate[amount][1]=y; //เก็บตำแหน่งxyไว้ใน Array
        amount++;
    }
    
}
class LoveCard extends Cardz{
    public LoveCard(int n, int x, int y) {
        super(n, x, y);
        Locate[amount][0]=x;
        Locate[amount][1]=y;
        amount++;
    }
    
}

class Seimzee {

   public static int Deck;
   public static int Randoms(){
       Random rand = new Random();

        int Value = rand.nextInt(4); //randomค่า
        return Value;
   
    }
     public static void Predict(){
    Deck = Randoms();
    System.out.println(Deck);
    if(Deck == 0){
         Sthhoro horo1 = new Sthhoro();
         horo1.setVisible(true);    
     }
      if(Deck == 1){
       Sthhoro2 horo2 = new Sthhoro2();
         horo2.setVisible(true);    
     }
      if(Deck == 2){
       Sthhoro3 horo3 = new Sthhoro3();
         horo3.setVisible(true);  
     }
      if(Deck == 3){
         Sthhoro4 horo4 = new Sthhoro4();
         horo4.setVisible(true);    
     }
      if(Deck == 4){
        Sthhoro5 horo5 = new Sthhoro5();
         horo5.setVisible(true);     
     }
      
      
      
 }
}